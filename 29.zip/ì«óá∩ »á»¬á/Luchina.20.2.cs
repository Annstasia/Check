﻿using System;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = { 1, 2, 3, 4, 5, 6, };

            for (int left = 0, right = array.Length - 1; left < array.Length / 2; left++, right--)
            {
                int c = array[left];
                array[left] = array[right];
                array[right] = c;
            }
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write(array[i] + " ");
            }
        }
    }
}
