﻿using System;

namespace ConsoleApp5
{
    class Program
    {
        static void Main(string[] args)
        {
            const int n = 6;
            int[] m = new int[n] { 2, 7, 19, 3, 8, 5 };
            for (int i = 0; i < n - 2; i++)
            {
                int mmax = m[i];
                int imax = i;
                for (int j = i + 1; j < n - 1; j++)
                {
                    if (m[j] > mmax)
                    {
                        mmax = m[j];
                        imax = j;
                    }
                }
                m[imax] = m[i];
                m[i] = mmax;
            }
            for (int i = 0; i < n; i++)
                Console.Write("{0:d} ", m[i]);
            Console.WriteLine();
            Console.ReadKey();

        }
    }
}
