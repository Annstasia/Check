﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[5] { 4, 3, 9, 5, 7 };
            int amax = a[0];
            int imax = 0;
            for (int i = 1; i < 5; i++)
            {
                if (a[i] > amax)
                {
                    amax = a[i];
                    imax = i;
                }
            }
            Console.WriteLine("Индекс максимального элемента {0:d} Значение максимального элемента { 1:d}", imax, a[imax]);
            Console.ReadKey();
        }
    }
}
