﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Massivs
{
    class Program
    {
        static void Main(string[] args)
        {
            var integers = Console.ReadLine().Split().Select(s => Convert.ToInt32(s)).ToArray();
            int a = integers.Length;
            int w = integers[a - 1];
            for (int i = a - 1; i > 0; i--)
            {
                integers[i] = integers[i - 1];
            }
            integers[0] = w;
            for (int i = 0; i < a; i++)
            {
                Console.Write(integers[i] + " ");
            }
            Console.ReadKey();
        }
    }
}