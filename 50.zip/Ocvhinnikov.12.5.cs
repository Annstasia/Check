﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        public static object BinSearch(int[] inputArray, int key)
        {
            int min = 0;
            int max = inputArray.Length - 1;
            while (min <= max)
            {
                int mid = (min + max) / 2;
                if (key == inputArray[mid])
                {
                    return ++mid;
                }
                else if (key < inputArray[mid])
                {
                    max = mid - 1;
                }
                else
                {
                    min = mid + 1;
                }
            }
            return "Nil";
        }
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            int[] a = new int[n];
            int[] b = new int[n];
            String[] inp = Console.ReadLine().Split();
            for (int i = 0; i < n; i++)
            {
                a[i] = Convert.ToInt32(inp[i]);
            }
            for (int i = 0; i < n; i++)
            {
                b[i] = a[n - i - 1];
            }
            for (int i = 0; i < n; i++)
            {
                Console.Write(b[i]);
                Console.Write(" ");
            }
            Console.ReadKey();
        }
    }
}
