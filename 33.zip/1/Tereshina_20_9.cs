﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp24
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[] { 1, 5, 3, 6,9, 9, 0,-3,8 };
            int m, ind;
            for(int i=0;i<a.Length;i++)
            {
                ind = i;
                m = a[i];
                for(int j=i+1;j<a.Length;j++)
                {
                    if(a[j]<m)
                    {
                        m = a[j];
                        ind = j;
                    }
                }
                a[ind] = a[i];
                a[i] = m;
            }
            foreach (int i in a) Console.Write(i+" ");
            Console.ReadKey();
        }
    }
}
