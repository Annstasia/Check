﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tereshina_20_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[] { 1, 2, 3, 4, 5 };
            int t = 0;
            for (int i = 0,j=a.Length-1; i < j; i++,j--)
            {
                t = a[i];
                a[i] = a[j];
                a[j] = t;
            }
            foreach (int i in a) Console.Write(i+" ");
            Console.ReadKey();
        }
    }
}
