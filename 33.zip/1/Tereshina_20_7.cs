﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp25
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[] { 1, 2, 3, 4, 5 };
            foreach (int i in a) Console.Write(i+" ");
            Console.Write("\nввод m: ");
            int m = int.Parse(Console.ReadLine());
            int t = 0;
            for (int i = 0; i < m; i++)
            {
                t = a[0];
                for (int j =0; j <a.Length-1; j++) a[j] = a[j + 1];
                a[a.Length-1] = t;
            }
            foreach (int i in a) Console.Write(i+" ");
            Console.ReadKey();
        }
    }
}
